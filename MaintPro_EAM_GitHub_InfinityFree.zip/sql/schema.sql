CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('admin','manager','planner','supervisor','technician','storekeeper','viewer') NOT NULL DEFAULT 'viewer',
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS assets (
 id INT AUTO_INCREMENT PRIMARY KEY,
 tag VARCHAR(80) NOT NULL UNIQUE,
 name VARCHAR(180) NOT NULL,
 type VARCHAR(100) NOT NULL,
 location VARCHAR(180) DEFAULT '',
 manufacturer VARCHAR(120) DEFAULT '',
 model VARCHAR(120) DEFAULT '',
 serial_number VARCHAR(120) DEFAULT '',
 criticality ENUM('A','B','C') NOT NULL DEFAULT 'B',
 status VARCHAR(50) NOT NULL DEFAULT 'Operacional',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notifications (
 id INT AUTO_INCREMENT PRIMARY KEY,
 notification_no VARCHAR(40) NOT NULL UNIQUE,
 asset_id INT NULL,
 description TEXT NOT NULL,
 priority VARCHAR(30) NOT NULL DEFAULT 'P3',
 status VARCHAR(40) NOT NULL DEFAULT 'Novo',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS maintenance_orders (
 id INT AUTO_INCREMENT PRIMARY KEY,
 order_no VARCHAR(40) NOT NULL UNIQUE,
 asset_id INT NULL,
 notification_id INT NULL,
 description TEXT NOT NULL,
 type VARCHAR(40) NOT NULL DEFAULT 'Corretiva',
 priority VARCHAR(30) NOT NULL DEFAULT 'P3',
 status VARCHAR(40) NOT NULL DEFAULT 'Criada',
 planned_hours DECIMAL(10,2) NOT NULL DEFAULT 0,
 actual_hours DECIMAL(10,2) NOT NULL DEFAULT 0,
 planned_date DATE NULL,
 start_date DATETIME NULL,
 finish_date DATETIME NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE SET NULL,
 FOREIGN KEY(notification_id) REFERENCES notifications(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS measurements (
 id INT AUTO_INCREMENT PRIMARY KEY,
 asset_id INT NOT NULL,
 parameter VARCHAR(80) NOT NULL,
 value DECIMAL(14,4) NOT NULL,
 unit VARCHAR(30) NOT NULL,
 status VARCHAR(30) DEFAULT 'Normal',
 measured_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS materials (
 id INT AUTO_INCREMENT PRIMARY KEY,
 part_number VARCHAR(100) NOT NULL UNIQUE,
 name VARCHAR(180) NOT NULL,
 stock DECIMAL(12,2) NOT NULL DEFAULT 0,
 min_stock DECIMAL(12,2) NOT NULL DEFAULT 0,
 max_stock DECIMAL(12,2) NOT NULL DEFAULT 0,
 lead_time_days INT NOT NULL DEFAULT 0,
 unit_cost DECIMAL(14,2) NOT NULL DEFAULT 0,
 critical_spare TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO assets(tag,name,type,location,criticality,status) VALUES
('P-101','Bomba de transferência','Bomba','Produção / Filtração','A','Operacional'),
('M-101','Motor elétrico','Motor elétrico','Produção / Envase','A','Operacional'),
('C-101','Compressor de ar','Compressor','Utilidades','A','Operacional'),
('CH-101','Chiller','Chiller','Utilidades','B','Operacional');

INSERT IGNORE INTO maintenance_orders(order_no,asset_id,description,type,priority,status,planned_hours)
SELECT 'WO-DEMO-001',id,'Inspeção de vibração','Preditiva','P2','Em execução',4 FROM assets WHERE tag='P-101';

INSERT IGNORE INTO notifications(notification_no,asset_id,description,priority,status)
SELECT 'N-DEMO-001',id,'Vibração elevada','P1','Em análise' FROM assets WHERE tag='P-101';
