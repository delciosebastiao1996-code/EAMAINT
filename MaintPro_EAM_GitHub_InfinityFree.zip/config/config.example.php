<?php
// Copie este ficheiro para config/config.php e preencha os dados do MySQL do InfinityFree.
// NÃO publique config.php no GitHub.
return [
    'db' => [
        'host' => 'SEU_MYSQL_HOST',
        'name' => 'SEU_DATABASE',
        'user' => 'SEU_DB_USER',
        'pass' => 'SUA_PASSWORD',
        'charset' => 'utf8mb4'
    ],
    'app' => [
        'name' => 'MaintPro EAM',
        'timezone' => 'Africa/Luanda'
    ]
];
?>