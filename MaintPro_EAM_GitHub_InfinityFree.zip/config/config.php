<?php
// Para desenvolvimento local, copie config.example.php e preencha.
// No InfinityFree, edite este ficheiro APENAS no servidor.
// Este ficheiro está no .gitignore.
return [
    'db' => [
        'host' => 'localhost',
        'name' => '',
        'user' => '',
        'pass' => '',
        'charset' => 'utf8mb4'
    ],
    'app' => [
        'name' => 'MaintPro EAM',
        'timezone' => 'Africa/Luanda'
    ]
];
?>