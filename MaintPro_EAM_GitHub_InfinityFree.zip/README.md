# MaintPro EAM — GitHub + InfinityFree

Sistema base de gestão de manutenção industrial com PHP 8.4 + MySQL/MariaDB.

## Estrutura
- `public/` interface web
- `api/` endpoints REST
- `config/` configuração e PDO
- `sql/` schema e dados demo

## GitHub
Suba estes ficheiros para um repositório privado ou público. Nunca publique `config/config.php` com passwords reais.

## InfinityFree
1. Crie o alojamento.
2. Crie uma base MySQL.
3. Importe `sql/schema.sql` pelo phpMyAdmin.
4. Edite `config/config.php` no servidor com host, nome, utilizador e password da base.
5. Envie `public/index.php`, `api/`, `config/` e `.htaccess` para a pasta `htdocs` (ou equivalente indicada pelo painel).
6. Abra o domínio.
7. Teste `api/health.php`.

Nota: o plano gratuito suporta PHP e MySQL/MariaDB. Esta versão não depende de Node.js, Python ou Docker no servidor.
