<?php
require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt=$pdo->query("SELECT o.*, a.tag asset_tag FROM maintenance_orders o LEFT JOIN assets a ON a.id=o.asset_id ORDER BY o.id DESC");
    respond(['ok'=>true,'data'=>$stmt->fetchAll()]);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $d=json_input();
    require_fields($d,['description']);
    $stmt=$pdo->prepare("INSERT INTO maintenance_orders(order_no,asset_id,description,type,priority,status,planned_hours) VALUES(?,?,?,?,?,?,?)");
    $no='WO-'.date('YmdHis');
    $stmt->execute([$no,$d['asset_id']??null,$d['description'],$d['type']??'Corretiva',$d['priority']??'P3',$d['status']??'Criada',$d['planned_hours']??0]);
    respond(['ok'=>true,'id'=>$pdo->lastInsertId(),'order_no'=>$no],201);
}
respond(['ok'=>false,'error'=>'Método não suportado'],405);
?>