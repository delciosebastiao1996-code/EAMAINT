<?php
require __DIR__ . '/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt=$pdo->query("SELECT n.*, a.tag asset_tag FROM notifications n LEFT JOIN assets a ON a.id=n.asset_id ORDER BY n.id DESC");
    respond(['ok'=>true,'data'=>$stmt->fetchAll()]);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $d=json_input();
    require_fields($d,['description']);
    $stmt=$pdo->prepare("INSERT INTO notifications(notification_no,asset_id,description,priority,status) VALUES(?,?,?,?,?)");
    $no='N-'.date('YmdHis');
    $stmt->execute([$no,$d['asset_id']??null,$d['description'],$d['priority']??'P3',$d['status']??'Novo']);
    respond(['ok'=>true,'id'=>$pdo->lastInsertId(),'notification_no'=>$no],201);
}
respond(['ok'=>false,'error'=>'Método não suportado'],405);
?>