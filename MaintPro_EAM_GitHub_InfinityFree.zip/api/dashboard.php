<?php
require __DIR__ . '/bootstrap.php';
$assets=(int)$pdo->query("SELECT COUNT(*) FROM assets")->fetchColumn();
$orders=(int)$pdo->query("SELECT COUNT(*) FROM maintenance_orders")->fetchColumn();
$open=(int)$pdo->query("SELECT COUNT(*) FROM maintenance_orders WHERE status NOT IN ('Concluída','Encerrada','Cancelada')")->fetchColumn();
$notifications=(int)$pdo->query("SELECT COUNT(*) FROM notifications WHERE status NOT IN ('Encerrada','Cancelada')")->fetchColumn();
respond(['ok'=>true,'data'=>[
    'assets'=>$assets,'orders'=>$orders,'open_orders'=>$open,'open_notifications'=>$notifications
]]);
?>