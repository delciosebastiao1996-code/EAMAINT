<?php
require __DIR__ . '/bootstrap.php';
$pdo->query('SELECT 1');
respond(['ok'=>true,'app'=>'MaintPro EAM','database'=>'connected','time'=>date('c')]);
?>