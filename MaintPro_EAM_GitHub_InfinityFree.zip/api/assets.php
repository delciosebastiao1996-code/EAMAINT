<?php
require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $q = trim($_GET['q'] ?? '');
    if ($q !== '') {
        $stmt = $pdo->prepare("SELECT * FROM assets WHERE tag LIKE ? OR name LIKE ? ORDER BY id DESC");
        $like="%$q%"; $stmt->execute([$like,$like]);
    } else {
        $stmt = $pdo->query("SELECT * FROM assets ORDER BY id DESC");
    }
    respond(['ok'=>true,'data'=>$stmt->fetchAll()]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $d=json_input();
    require_fields($d,['tag','name','type']);
    $stmt=$pdo->prepare("INSERT INTO assets(tag,name,type,location,criticality,status) VALUES(?,?,?,?,?,?)");
    $stmt->execute([$d['tag'],$d['name'],$d['type'],$d['location']??'', $d['criticality']??'B', $d['status']??'Operacional']);
    respond(['ok'=>true,'id'=>$pdo->lastInsertId()],201);
}
respond(['ok'=>false,'error'=>'Método não suportado'],405);
?>